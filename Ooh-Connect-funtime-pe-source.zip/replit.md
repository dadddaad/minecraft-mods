# Ooh Connect

Fabric client mod for Minecraft Java 1.21.4 that adds a separate PE/Bedrock
server screen and a ready-to-use FUNTIME preset.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `funtime-pe-mod/` — the actual Fabric mod.
- `funtime-pe-mod/src/main/java/dev/funtime/pe/` — PE server screen, config,
  connection flow, and the multiplayer-screen button.
- `funtime-pe-mod/src/main/resources/` — Fabric metadata and mixin config.
- `funtime-pe-mod/libs/` — the pinned ViaFabricPlus/ViaBedrock libraries used by
  the mod.
- `artifacts/` and `lib/` — the original Replit workspace scaffold.

## Architecture decisions

- The bridge uses ViaFabricPlus' Bedrock protocol translator instead of
  implementing a second network stack.
- FUNTIME is a preset, not a hard-coded-only destination: the host, port,
  display name, and nickname can be changed in the screen.
- Settings are stored in `config/funtimepe.properties` through Fabric Loader's
  config directory.
- Microsoft device-code login is delegated to ViaFabricPlus, so credentials
  never belong to this mod.

## Product

From the Multiplayer screen, **PE / Bedrock** opens a dedicated form where the
player can load the FUNTIME address, complete the required Microsoft Bedrock
login, and connect through ViaFabricPlus.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- The mod targets Minecraft Java 1.21.4 and Java 21.
- ViaFabricPlus 3.6.1 and the bundled ViaBedrock libraries must stay compatible
  with that Minecraft version.
- A Microsoft Bedrock account is required; a nickname is never used as an
  authentication fallback.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
